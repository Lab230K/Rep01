﻿import cv2 as cv
import numpy as np
def main():
    # 500(高さ) x 500(幅)　3レイヤー(BGR)を定義
    size = (500, 500, 3)
    # 空の配列
    img = np.zeros(size, dtype=np.uint8)
    # 画像，テキスト，位置（左下），フォント，スケール，色，線太さ，種類
    cv.putText(img, 'Sample01', (20,50), cv.FONT_HERSHEY_SIMPLEX, 1.2, (0,0,200), 2, cv.LINE_AA)
    cv.putText(img, 'Sample02', (20,100), cv.FONT_HERSHEY_PLAIN, 1.2, (0,200,0), 2, cv.LINE_AA)
    cv.putText(img, 'Sample03', (20,150), cv.FONT_HERSHEY_DUPLEX, 1.2, (200,0,0), 2, cv.LINE_AA)
    cv.putText(img, 'Sample04', (20,200), cv.FONT_HERSHEY_COMPLEX, 1.2, (0,100,100), 2, cv.LINE_AA)
    cv.putText(img, 'Sample05', (20,250), cv.FONT_HERSHEY_TRIPLEX, 1.2, (100,100,0), 2, cv.LINE_AA)
    cv.putText(img, 'Sample06', (20,300), cv.FONT_HERSHEY_COMPLEX_SMALL, 1.2, (100,0,100), 2, cv.LINE_AA)
    cv.putText(img, 'Sample07', (20,350), cv.FONT_HERSHEY_SCRIPT_SIMPLEX, 1.2, (100,100,100), 2, cv.LINE_AA)
    cv.putText(img, 'Sample08', (20,400), cv.FONT_HERSHEY_SCRIPT_COMPLEX, 1.2, (100,100,200), 2, cv.LINE_AA)
    cv.putText(img, 'Sample09', (250,50), cv.FONT_HERSHEY_SIMPLEX | cv.FONT_ITALIC, 1.2, (100,200,100), 2, cv.LINE_AA)
    cv.putText(img, 'Sample10', (250,100), cv.FONT_HERSHEY_PLAIN | cv.FONT_ITALIC, 1.2, (200,100,100), 2, cv.LINE_AA)
    cv.putText(img, 'Sample11', (250,150), cv.FONT_HERSHEY_DUPLEX | cv.FONT_ITALIC, 1.2, (200,200,100), 2, cv.LINE_AA)
    cv.putText(img, 'Sample12', (250,200), cv.FONT_HERSHEY_COMPLEX | cv.FONT_ITALIC, 1.2, (200,100,200), 2, cv.LINE_AA)
    cv.putText(img, 'Sample13', (250,250), cv.FONT_HERSHEY_TRIPLEX | cv.FONT_ITALIC, 1.2, (100,200,200), 2, cv.LINE_AA)
    cv.putText(img, 'Sample14', (250,300), cv.FONT_HERSHEY_COMPLEX_SMALL | cv.FONT_ITALIC, 1.2, (100,200,255), 2, cv.LINE_AA)
    cv.putText(img, 'Sample15', (250,350), cv.FONT_HERSHEY_SCRIPT_SIMPLEX | cv.FONT_ITALIC, 1.2, (100,255,200), 2, cv.LINE_AA)
    cv.putText(img, 'Sample16', (250,400), cv.FONT_HERSHEY_SCRIPT_COMPLEX | cv.FONT_ITALIC, 1.2, (255,200,100), 2, cv.LINE_AA)
    cv.imwrite('result.png', img)
if __name__ == '__main__':
    main()